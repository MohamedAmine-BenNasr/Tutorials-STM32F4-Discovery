#include "DS1620.h"
#include "cmsis_os.h"

void Config_DQ_Out(void)
{
	  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}


void Config_DQ_In(void)
{
		  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();


  /*Configure GPIO pins : PA3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}


void DS1620_init(void)
{
     //P3 = 0x00;
     DS1620_write_config(0x0A);
}


void DS1620_rst_start(void)
{
		 Config_DQ_Out();
     HAL_GPIO_WritePin(GPIOA, RST_pin, GPIO_PIN_RESET);
     HAL_GPIO_WritePin(GPIOA, CLK_pin, GPIO_PIN_SET);
     HAL_GPIO_WritePin(GPIOA, RST_pin, GPIO_PIN_SET);
}


void DS1620_rst_stop(void)
{
     HAL_GPIO_WritePin(GPIOA, RST_pin, GPIO_PIN_RESET);
}


void DS1620_start_conv(void)
{
     DS1620_rst_start();
     DS1620_send_command(start_temperature_conversion_command);
     DS1620_rst_stop();
}


void DS1620_stop_conv(void)
{
     DS1620_rst_start();
     DS1620_send_command(stop_temperature_conversion_command);
     DS1620_rst_stop();
}

/**************************************Send Command**************************************/
void DS1620_send_command(unsigned char command)
{
    unsigned char n = 0;
    unsigned char b = 0;

		Config_DQ_Out();
	
    for(n = 0; n < 8; n++)
    {
         b = ((command >> n) & 0x1);
				 if (b == 0x01)
					 HAL_GPIO_WritePin(GPIOA, DQ_pin, GPIO_PIN_SET);
				 else
					 HAL_GPIO_WritePin(GPIOA, DQ_pin, GPIO_PIN_RESET);
				 
         HAL_GPIO_WritePin(GPIOA, CLK_pin, GPIO_PIN_RESET);
         HAL_GPIO_WritePin(GPIOA, CLK_pin, GPIO_PIN_SET);
    }
}

/****************************************Get Data**************************************/
signed int DS1620_get_data(void)
{
    unsigned char n = 0x00;
    
    signed int b = 0x0000;
    signed int value = 0x0000;
		
		
    HAL_GPIO_WritePin(GPIOA, DQ_pin, GPIO_PIN_SET);
		Config_DQ_In();
    
    for(n = 0; n < 9; n++)
    {
        HAL_GPIO_WritePin(GPIOA, CLK_pin, GPIO_PIN_RESET);
        b = HAL_GPIO_ReadPin(GPIOA, DQ_pin);
        HAL_GPIO_WritePin(GPIOA, CLK_pin, GPIO_PIN_SET);
        value = (value | b << n);
    }
    
		Config_DQ_Out();
    HAL_GPIO_WritePin(GPIOA, DQ_pin, GPIO_PIN_RESET);

    return value;
}


unsigned char DS1620_read_config(void)
{
    unsigned char value = 0x00;

    DS1620_rst_start();
    DS1620_send_command(read_configuration_command);
    value = DS1620_get_data();
    DS1620_rst_stop();
    return value;
}


unsigned char DS1620_write_config(unsigned char value)
{
    if(value > 0) 
    {
        DS1620_rst_start();
        DS1620_send_command(write_configuration_command);
        DS1620_send_command(value);
        osDelay(20);
        DS1620_rst_stop();
        
        if(DS1620_read_config() == value)
        { 
            return write_successful;
        }
        else 
        { 
            return write_unsuccessful;
        }
    }
    return bad_configuration;
}


signed int DS1620_read_TH(void)
{
    signed int value = 0x0000;

    DS1620_rst_start();
    DS1620_send_command(read_TH_command);
    value = (DS1620_get_data() >> 1);
    DS1620_rst_stop();
    return value;
}


signed int DS1620_read_TL(void)
{
    signed int value = 0x0000;

    DS1620_rst_start();
    DS1620_send_command(read_TL_command);
    value = (DS1620_get_data() >> 1);
    DS1620_rst_stop();
    return value;
}


signed int DS1620_read_counter(void)
{
    signed int value = 0x0000;

    DS1620_rst_start();
    DS1620_send_command(read_counter_command);
    value = DS1620_get_data();
    DS1620_rst_stop();
    return value;
}


signed int DS1620_read_slope(void)
{
    signed int value = 0x0000;

    DS1620_rst_start();
    DS1620_send_command(read_slope_command);
    value = DS1620_get_data();
    DS1620_rst_stop();
    return value;
}


void DS1620_write_TH(signed int value)
{
    unsigned char n = 0;
    signed int b = 0x0000;

    value = value << 1;
    DS1620_rst_start();
    DS1620_send_command(write_TH_command);
    for(n = 0; n < 9; n++)
    {
        b = ((value >> n) & 0x1);
				if (b == 0x01)
					HAL_GPIO_WritePin(GPIOA, DQ_pin, GPIO_PIN_SET);
				else
					HAL_GPIO_WritePin(GPIOA, DQ_pin, GPIO_PIN_RESET);
				
        HAL_GPIO_WritePin(GPIOA, CLK_pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, CLK_pin, GPIO_PIN_SET);
    }
    osDelay(20);
    DS1620_rst_stop();
}


void DS1620_write_TL(signed int value)
{
    unsigned char n = 0;
    signed int b = 0x0000;

    value = value << 1;
    DS1620_rst_start();
    DS1620_send_command(write_TL_command);
    for(n = 0; n < 9; n++)
    {
        b = ((value >> n) & 0x1);
				if (b == 0x01)
					HAL_GPIO_WritePin(GPIOA, DQ_pin, GPIO_PIN_SET);
				else
					HAL_GPIO_WritePin(GPIOA, DQ_pin, GPIO_PIN_RESET);
					

        HAL_GPIO_WritePin(GPIOA, CLK_pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, CLK_pin, GPIO_PIN_SET);
    }
    osDelay(20);
    DS1620_rst_stop();
}


void DS1620_read_T(signed char *m, unsigned char *f)
{
    signed int value = 0x00;

    DS1620_rst_start();
    DS1620_send_command(read_temperature_command);
    value = DS1620_get_data();
    DS1620_rst_stop();

    if (value & 0x0100)
    {
        value &= 0x00FF;
        value = 0x0100 - value;
        value = -value;
    }

    *m = value >>= 1;
    
    if(value & 0x01)
    {
        *f = 5;
    }
    else
    {
       *f = 0;
    }
}

