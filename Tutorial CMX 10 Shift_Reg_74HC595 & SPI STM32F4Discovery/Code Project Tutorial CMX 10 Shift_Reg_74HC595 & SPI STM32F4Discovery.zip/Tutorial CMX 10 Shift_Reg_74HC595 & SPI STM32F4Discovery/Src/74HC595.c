#include "74HC595.h"

const uint8_t nbShift = 1;


void Send_Tx_74HC595(SPI_HandleTypeDef hspi , uint8_t TxBuffer , uint16_t Size)
{
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_3,GPIO_PIN_RESET);
	
	HAL_SPI_Transmit(&hspi , &TxBuffer , Size , 10 );
	
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_3,GPIO_PIN_SET);
}


void ShiftLeft_Tx_74HC595 (SPI_HandleTypeDef hspi , uint8_t TxBuffer , uint16_t Size)
{
	
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_3,GPIO_PIN_RESET);
	
	HAL_SPI_Transmit(&hspi,&TxBuffer,Size,10);
	
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_3,GPIO_PIN_SET);
	
	TxBuffer = TxBuffer << nbShift;

}

void ShiftRight_Tx_74HC595 (SPI_HandleTypeDef hspi , uint8_t TxBuffer , uint16_t Size)
{
	
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_3,GPIO_PIN_RESET);
	
	HAL_SPI_Transmit(&hspi,&TxBuffer,Size,10);
	
	HAL_GPIO_WritePin(GPIOE,GPIO_PIN_3,GPIO_PIN_SET);
	
	TxBuffer = TxBuffer >> nbShift;
	
}
