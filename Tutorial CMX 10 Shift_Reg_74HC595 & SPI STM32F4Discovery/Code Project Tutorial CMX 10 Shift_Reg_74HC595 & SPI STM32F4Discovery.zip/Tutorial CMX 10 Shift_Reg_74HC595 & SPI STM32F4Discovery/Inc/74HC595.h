#ifndef __74HC595_H
#define __74HC595_H

#include "stm32f4xx_hal.h"	

#ifdef __cplusplus
 extern "C" {
#endif 
	
 
	 
void Send_Tx_74HC595       (SPI_HandleTypeDef hspi , uint8_t TxBuffer , uint16_t Size);
	 
void ShiftLeft_Tx_74HC595  (SPI_HandleTypeDef hspi , uint8_t TxBuffer , uint16_t Size); 
	 
void ShiftRight_Tx_74HC595 (SPI_HandleTypeDef hspi , uint8_t TxBuffer , uint16_t Size); 
	






	 
#ifdef __cplusplus
}
#endif 


#endif 