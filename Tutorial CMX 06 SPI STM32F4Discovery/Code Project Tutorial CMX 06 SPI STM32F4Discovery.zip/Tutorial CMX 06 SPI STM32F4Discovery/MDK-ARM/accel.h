#ifndef __ACCEL_H
#define __ACCEL_H




/* Who I am values */
#define LIS302DL_ID							0x3B
#define LIS3DSH_ID							0x3F

/* Common registers */
#define LIS302DL_LIS3DSH_REG_WHO_I_AM		0x0F

/* ----------------------------------------- */
/* LIS3DSH registers */
/* ----------------------------------------- */
#define LIS3DSH_WHO_AM_I_ADDR				0x0F
#define LIS3DSH_CTRL_REG4_ADDR			0x20
#define LIS3DSH_CTRL_REG1_ADDR			0x21
#define LIS3DSH_CTRL_REG2_ADDR			0x22
#define LIS3DSH_CTRL_REG3_ADDR			0x23
#define LIS3DSH_CTRL_REG5_ADDR			0x24
#define LIS3DSH_CTRL_REG6_ADDR			0x25
#define LIS3DSH_OUT_X_L_ADDR				0x28 | 0x80
#define LIS3DSH_OUT_X_H_ADDR				0x29 | 0x80
#define LIS3DSH_OUT_Y_L_ADDR				0x2A | 0x80
#define LIS3DSH_OUT_Y_H_ADDR				0x2B | 0x80
#define LIS3DSH_OUT_Z_L_ADDR				0x2C | 0x80
#define LIS3DSH_OUT_Z_H_ADDR				0x2D | 0x80

#endif